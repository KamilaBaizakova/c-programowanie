﻿using System;
using System.Collections.Generic;
using System.Text;

namespace KomisSamochodowy
{
    public class Samochod
    {
        public string Marka { get; set; }
        public string Model { get; set; }
        public string Kolor { get; set; }
        public string Silnik { get; set; }
        public decimal Cena { get; set; }

        public string Desc
        {
            get
            {
                return $"{Marka} {Model} {Silnik}";
            }
        }

        public Samochod(string marka, string model, string kolor, string silnik, decimal cena)
        {
            Marka = marka;
            Model = model;
            Kolor = kolor;
            Silnik = silnik;
            Cena = cena;
        }

        public override string ToString()
        {
            return $"{Marka} {Model} {Silnik} w kolorze: {Kolor}, cena: {Cena} zł";
        }


    }
}
