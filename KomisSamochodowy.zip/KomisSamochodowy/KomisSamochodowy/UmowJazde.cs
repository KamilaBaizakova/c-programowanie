﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace KomisSamochodowy
{
    public partial class UmowJazde : Form
    {
        public JazdyProbne jp;

        public UmowJazde(JazdyProbne jp)
        {
            InitializeComponent();

            this.jp = jp;

            comboBox1.Items.AddRange(jp.win.samochody.Select(s => s.Desc).ToArray());
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DateTime data;

            if(!DateTime.TryParse(textBox1.Text,out data) || string.IsNullOrEmpty(comboBox1.SelectedItem.ToString()) || string.IsNullOrEmpty(textBox2.Text))
            {
                MessageBox.Show("Uzupełnij poprawnie wszystkie pola");
            }
            else
            {
                jp.win.jazdy.Add(new JazdaProbna(comboBox1.SelectedItem.ToString(), data, textBox2.Text));
                jp.Read();
                jp.Enabled = true;
                this.Close();
            }
        }
    }
}
