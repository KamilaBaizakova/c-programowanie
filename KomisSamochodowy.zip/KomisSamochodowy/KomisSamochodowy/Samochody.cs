﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace KomisSamochodowy
{
    public partial class Samochody : Form
    {
        public Form1 win { get; set; }

        public Samochody(Form1 win)
        {
            InitializeComponent();
            this.win = win;

            Read();
        }

        public void Read()
        {
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = win.samochody;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DodajSamochod ds = new DodajSamochod(this);
            ds.Show();
            this.Enabled = false;
        }

        private void Samochody_FormClosed(object sender, FormClosedEventArgs e)
        {
            win.Enabled = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(dataGridView1.SelectedRows.Count != 0)
            {
                var row = dataGridView1.SelectedRows[0];
                int i = dataGridView1.Rows.IndexOf(row);

                if (i < win.samochody.Count)
                {
                    win.samochody.RemoveAt(i);
                    Read();
                }
                else
                {
                    MessageBox.Show("Wybierz samochód do usunięcia.");
                }
            }
            else
            {
                MessageBox.Show("Wybierz samochód do usunięcia.");
            }
        }
    }
}
